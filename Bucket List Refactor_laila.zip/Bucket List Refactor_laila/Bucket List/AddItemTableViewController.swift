//
//  AddItemViewController.swift
//  Bucket List
//
//  Created by administrator on 14/12/2021.
//

import UIKit

class AddItemTableViewController: UITableViewController {
    
    weak var delegate: AddItemTableViewControllerDelegate?
    
    var itemEdit: String?
    
    var indexPath: NSIndexPath?
    
    @IBOutlet weak var itemTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        itemTextField.text = itemEdit
    }

    @IBAction func cancleButtonPressed(_ sender: UIBarButtonItem) {
        
        delegate?.cancleButtonPressed(by: self)
    }
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        
        guard let text = itemTextField.text else {return}
        delegate?.itemSaved(by: self, with: text, at :indexPath)
    }
}
