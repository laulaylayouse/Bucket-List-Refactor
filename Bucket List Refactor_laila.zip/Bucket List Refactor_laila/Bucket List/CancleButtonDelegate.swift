//
//  CancleButtonDelegate.swift
//  Bucket List
//
//  Created by Mac on 08/05/1443 AH.
//

import UIKit

protocol CancleButtonDelegate : AnyObject {
  
    func cancleButtonPressed(by controller: UIViewController)
}
